# RDC 每日缺货报告生成 · Skill 分享与安装说明

> 分享人：张宇飞（供应链分仓计划组）｜ 适用：WorkBuddy 用户级 Skill

## 一、这个 Skill 做什么
把当日的 RDC 缺货数据源，自动套进标准 Excel 模板，计算出每一行的「缺货原因」
（总仓缺货 / 超销-常规品 / 超销-促销装 / SPU缺失 / 淘汰产品 / 超销-新品），
并补全补货到货时间、CDC 到货时间等列，最终生成一份独立的
`缺货报告_YYYYMMDD.xlsx`，**不覆盖任何源文件**。

适用人群：供应链分仓计划 / 补货计划同学，每天生成并归档缺货报告。

## 二、安装步骤
1. 解压本压缩包，得到 `rdc-stockout-report` 文件夹。
2. 把它复制到 WorkBuddy 的 skills 目录：
   - Windows：`C:\Users\<你的用户名>\.workbuddy\skills\rdc-stockout-report\`
   - macOS / Linux：`~/.workbuddy/skills/rdc-stockout-report/`
3. 安装 Python 依赖（只需一次）：
   ```
   pip install openpyxl
   ```

## 三、⚠️ 必须配置：工作目录路径（否则运行会找不到文件）
Skill 默认工作目录写死在 `scripts/generate_stockout_report.py` 第 32 行：
```python
DEFAULT_DIR = 'S:/供应链/供应链计划部/03.创新/15.补货计划工作记录/缺货报告'
```
请改成**你自己的**共享文件夹路径（即你的模板 / 数据源 / KA 报告所在目录）。
两种改法任选其一：
- **改默认值**：直接编辑第 32 行，替换为你的路径；
- **运行时指定**：不改代码，每次运行加参数：
  ```
  python generate_stockout_report.py --dir "你的路径"
  ```
> 建议同时把 `SKILL.md` 顶部的「工作目录（写死）」说明也改成本机路径，方便日后查阅（不影响功能）。

## 四、准备数据文件
在你的工作目录里，需要放齐三个文件（文件名含关键字即可，脚本会自动识别）：
- 模板：`缺货报告模版.xlsx`（3 个 sheet：缺货报告 / 缺货原因 / 基础数据）
- 当日数据源：`*缺货数据*.xlsx` 或 `26xxxx.xlsx`（sheet 名为 `SPU Label`）
- KA 报告：`*ka缺货报告*.xlsx`（用于抓取 CDC 到货时间）

> 报告日 = 数据源文件名里的日期（如 `260728缺货数据.xlsx` → 2026-07-28）。
> 输出 `缺货报告_YYYYMMDD.xlsx` 存回同一工作目录（另存新文件，绝不覆盖源文件）。

## 五、怎么用
- **方式 A（推荐）**：在 WorkBuddy 对话里直接说「更新缺货报告」，Skill 会自动识别
  最新数据源并生成。
- **方式 B（手动）**：
  ```
  python "路径/rdc-stockout-report/scripts/generate_stockout_report.py" --dir "你的工作目录"
  ```

## 六、注意事项
- 模板 / 数据源 / KA 报告均为**只读**，脚本会另存为新文件，绝不回写源文件。
- 模板 Q/R 列公式引用外部工作簿，打开生成的报告时可能提示「更新链接」，属预期，按需选择即可。
- 若需要调整补货排班（哪天哪个 RDC 补货），改模板「基础数据」sheet 右侧的补货日期段即可。
- 缺货原因判定顺序：SPU缺失 → CDC≤1(淘汰/总仓缺货) → 供给不足(总仓缺货) → 新品 → 常规品 → 促销装。

## 七、目录结构
```
rdc-stockout-report/
├── SKILL.md                            # Skill 说明（WorkBuddy 自动加载）
├── scripts/
│   └── generate_stockout_report.py     # 报告生成主脚本
└── README-分享与安装.md                # 本文件
```
