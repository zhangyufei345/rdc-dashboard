#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
RDC 每日缺货报告一键生成器
==========================
默认从固定共享目录读取【模板 / 当日数据源 / KA缺货报告】，按最新业务规则生成
当日 T-1 的缺货报告，另存为新文件（绝不回写/覆盖任何源文件）。

用法：
    python generate_stockout_report.py                 # 全自动：目录/文件/日期都自动检测
    python generate_stockout_report.py --dir "S:/..."  # 指定目录
    python generate_stockout_report.py --date 2026-07-10  # 指定报告日(T-1)，默认=今天-1
    python generate_stockout_report.py --src "..xlsx" --ka "..xlsx" --tpl "..xlsx" --out "..xlsx"

规则见同目录 ../SKILL.md。核心：
  缺货原因 判定顺序：C(SPU缺失,最高优先级) → A/B(总仓缺货/淘汰) → B2(总仓缺货) → 超销-新品 → D → E；
  （C 必须排最前：产品不在基础数据主数据时应判 SPU缺失，而非被 cdc≤1 误判为总仓缺货）
  （B2新增：RDC总库存 + RDC在途库存 + CDC库存量 < 未清量，也判 总仓缺货）
  K列=KA最新日期"预计进大仓时间"；J列变动3/4补货日填充；
  变动5：在途数量<缺货数量 且 本身有在途量、原因非淘汰/总仓缺货 → J末尾追加"剩余缺口预计M-D补货"(日期同字段空白时的 next_replen 逻辑)；
  淘汰产品行整行灰色 FFCCCCCC，其余保留模板原底色。
"""
import argparse, glob, os, re, shutil, sys
from copy import copy
from datetime import date, timedelta
from collections import Counter

import openpyxl
from openpyxl.styles import PatternFill, Color
from openpyxl.utils import get_column_letter

DEFAULT_DIR = 'S:/供应链/供应链计划部/03.创新/15.补货计划工作记录/缺货报告'


# ---------------- helpers ----------------
def to_num(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return v
    if isinstance(v, str):
        s = v.strip()
        if s == '':
            return None
        try:
            f = float(s)
            return int(f) if f.is_integer() else f
        except Exception:
            return None
    return None


def to_num_rule(v):
    n = to_num(v)
    return n if n is not None else 0


def norm_code(x):
    s = str(x).strip()
    try:
        return str(int(float(s)))
    except Exception:
        return s


def norm_rdc(x):
    return re.sub(r'RDC$', '', str(x).strip(), flags=re.I).strip()


def copy_style(src_cell, dst_cell):
    if src_cell.has_style:
        dst_cell.font = copy(src_cell.font)
        dst_cell.border = copy(src_cell.border)
        dst_cell.fill = copy(src_cell.fill)
        dst_cell.number_format = copy(src_cell.number_format)
        dst_cell.protection = copy(src_cell.protection)
        dst_cell.alignment = copy(src_cell.alignment)


def parse_mdrange(s):
    m = re.match(r'(\d+)\.(\d+)\s*-\s*(\d+)\.(\d+)', str(s).strip())
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4))) if m else None


def pick_file(directory, patterns, label):
    """在目录里按多个通配模式找文件，返回最近修改的一个。"""
    hits = []
    for pat in patterns:
        hits += glob.glob(os.path.join(directory, pat))
    hits = [h for h in hits if not os.path.basename(h).startswith('~$')]
    if not hits:
        raise FileNotFoundError(f'目录里找不到{label}（模式 {patterns}）：{directory}')
    hits.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return hits[0].replace('\\', '/')


# ---------------- main ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', default=DEFAULT_DIR, help='工作目录（模板/数据源/KA 所在）')
    ap.add_argument('--date', default=None, help='报告日 T-1，格式 YYYY-MM-DD，默认=今天-1')
    ap.add_argument('--tpl', default=None)
    ap.add_argument('--src', default=None)
    ap.add_argument('--ka', default=None)
    ap.add_argument('--out', default=None)
    args = ap.parse_args()

    DIR = args.dir.replace('\\', '/')

    # 先确定数据源（需要从文件名提取日期）
    if args.src:
        SRC = args.src
    else:
        try:
            SRC = pick_file(DIR, ['*缺货数据*.xlsx'], '数据源')
        except FileNotFoundError:
            cand = [p for p in glob.glob(os.path.join(DIR, '*.xlsx'))
                    if re.match(r'\d{6}', os.path.basename(p))
                    and '模版' not in p and '模板' not in p
                    and 'ka' not in os.path.basename(p).lower()
                    and '缺货报告_' not in os.path.basename(p)
                    and not os.path.basename(p).startswith('~$')]
            if not cand:
                raise
            cand.sort(key=lambda p: os.path.getmtime(p), reverse=True)
            SRC = cand[0].replace('\\', '/')

    # 从数据源文件名提取日期作为报告日（文件名如 260721 表示报告日 2026-07-21）
    # 数据源 A 列通常为报告日+1（实际业务日期）
    src_basename = os.path.basename(SRC)
    src_m = re.match(r'(\d{6})', src_basename)
    if src_m:
        sy, sm, sd = int('20' + src_m.group(1)[:2]), int(src_m.group(1)[2:4]), int(src_m.group(1)[4:6])
        T_DATE = date(sy, sm, sd)
    else:
        T_DATE = date.today()

    if args.date:
        y, m, d = map(int, args.date.split('-'))
        REPORT_DATE = date(y, m, d)
    else:
        REPORT_DATE = T_DATE

    TPL = args.tpl or pick_file(DIR, ['缺货报告模版.xlsx', '缺货报告模板.xlsx'], '模板')
    # 数据源：优先"缺货数据"，否则纯数字命名 26xxxx.xlsx（排除模板/KA/已生成报告）
    KA = args.ka or pick_file(DIR, ['*ka缺货报告*.xlsx', '*KA缺货报告*.xlsx', '线下经销商*.xlsx'], 'KA缺货报告')
    OUT = args.out or f'{DIR}/缺货报告_{REPORT_DATE.strftime("%Y%m%d")}.xlsx'

    print('工作目录 :', DIR)
    print('模板     :', os.path.basename(TPL))
    print('数据源   :', os.path.basename(SRC))
    print('KA报告   :', os.path.basename(KA))
    print('报告日  :', REPORT_DATE)
    print('输出     :', os.path.basename(OUT))
    print('-' * 40)

    # ---- load ----
    wb_tpl = openpyxl.load_workbook(TPL, data_only=False)
    ws = wb_tpl['缺货报告']
    ws_base = wb_tpl['基础数据']
    wb_src = openpyxl.load_workbook(SRC, data_only=False)
    ws_src = wb_src['SPU Label'] if 'SPU Label' in wb_src.sheetnames else wb_src.active
    wb_ka = openpyxl.load_workbook(KA, data_only=False)

    # ---- 1) 基础数据 lookups ----
    base_pairs = set()
    new_codes = set()
    for rr in range(2, ws_base.max_row + 1):
        code = ws_base.cell(row=rr, column=1).value
        loc = ws_base.cell(row=rr, column=3).value
        if code is not None and loc is not None:
            base_pairs.add((str(code).strip(), str(loc).strip()))
        icode = ws_base.cell(row=rr, column=9).value
        if icode is not None and str(icode).strip() != '':
            new_codes.add(norm_code(icode))
    print(f'base_pairs={len(base_pairs)}, new_codes(新品清单)={len(new_codes)}')

    # ---- 2) 补货日期段（动态列检测） ----
    date_col = None
    for c in range(1, ws_base.max_column + 1):
        if ws_base.cell(row=1, column=c).value == '日期':
            date_col = c
            break
    segments = []
    if date_col is None:
        print('⚠️ 基础数据未找到"日期"列，跳过补货日填充（变动4）')
    else:
        mon_cols = list(range(date_col + 1, date_col + 7))
        print(f'补货日期段: 段标识列={get_column_letter(date_col)}, 周一~周六列={[get_column_letter(c) for c in mon_cols]}')
        cur = None
        for rr in range(1, ws_base.max_row + 1):
            L = ws_base.cell(row=rr, column=date_col).value
            Ls = str(L).strip() if L is not None else ''
            if Ls == '日期':
                continue
            if Ls == '默认':
                cur = {}; segments.append(('默认', 'default', cur))
            elif parse_mdrange(Ls):
                cur = {}; segments.append((Ls, 'adj', cur))
            if cur is not None:
                for idx, c in enumerate(mon_cols):
                    v = ws_base.cell(row=rr, column=c).value
                    if v is not None and str(v).strip() != '':
                        cur.setdefault(str(v).strip(), set()).add(idx)
        print('解析到的段:', [(lab, kind, {k: sorted(v) for k, v in mp.items()}) for lab, kind, mp in segments])

    # 选段
    sel = None
    for lab, kind, mp in segments:
        if kind == 'adj':
            m1, d1, m2, d2 = parse_mdrange(lab)
            if date(REPORT_DATE.year, m1, d1) <= REPORT_DATE <= date(REPORT_DATE.year, m2, d2):
                sel = mp; print(f'报告日落在调整段 {lab}'); break
    if sel is None:
        for lab, kind, mp in segments:
            if kind == 'default':
                sel = mp; print('用默认段'); break

    def next_replen(rdc):
        if not sel:
            return None
        k = norm_rdc(rdc)
        if k not in sel:
            return None
        wds = sorted(sel[k])
        monday = REPORT_DATE - timedelta(days=REPORT_DATE.weekday())
        cands = []
        for w in wds:
            cands += [monday + timedelta(days=w), monday + timedelta(days=w + 7)]
        for c in sorted(cands):
            if c > REPORT_DATE:
                return c
        return None

    # ---- 3) KA 最新日期 CDC到货时间 ----
    ka_map = {}
    best_sheet = None; best_date = None
    for sname in wb_ka.sheetnames:
        if sname == '汇总':
            continue
        m = re.match(r'(\d{2})(\d{2})$', sname.strip())
        if not m:
            continue
        d = date(REPORT_DATE.year, int(m.group(1)), int(m.group(2)))
        if best_date is None or d > best_date:
            best_date = d; best_sheet = sname
    if best_sheet:
        ws_ka = wb_ka[best_sheet]
        hdr = [ws_ka.cell(row=3, column=c).value for c in range(1, ws_ka.max_column + 1)]
        prod_col = eta_col = None
        for i, h in enumerate(hdr, 1):
            if h == '产品编号':
                prod_col = i
            if h == '预计进大仓时间':
                eta_col = i
        if prod_col and eta_col:
            for rr in range(4, ws_ka.max_row + 1):
                prod = ws_ka.cell(row=rr, column=prod_col).value
                eta = ws_ka.cell(row=rr, column=eta_col).value
                if prod is None:
                    continue
                ps = str(prod).strip()
                if '合计' in ps:
                    continue
                if eta is not None:
                    ka_map[norm_code(ps)] = str(eta).strip()
    print(f'KA 最新sheet={best_sheet}, 命中CDC到货={len(ka_map)}')

    # ---- 4) reason ----
    def reason(rdc, mat, cat, abc, cdc, rdc_stock, rdc_transit, backlog):
        # C（最高优先级）：缺货报告的(商品编号, 收货库位) 在基础数据 A+C 列查不到
        #    说明该SPU/库位组合未登入主数据，应判 SPU缺失，而非总仓缺货
        #    （必须排在 CDC 判定之前：否则 cdc≤1/None 会先被误判为总仓缺货）
        if (str(mat).strip(), str(rdc).strip()) not in base_pairs:
            return 'SPU缺失'
        # A/B：CDC库存 ≤ 1（淘汰仅当 ABC=Z）
        if to_num_rule(cdc) <= 1:
            return '淘汰产品' if str(abc).strip() == 'Z' else '总仓缺货'
        # B2（新增）：RDC总库存 + RDC在途库存 + CDC库存量 < 未清量 → 总仓缺货
        if (to_num_rule(rdc_stock) + to_num_rule(rdc_transit) + to_num_rule(cdc)) < to_num_rule(backlog):
            return '总仓缺货'
        if norm_code(mat) in new_codes:
            return '超销-新品'
        if str(cat).strip() == '常规品':
            return '超销-常规品'
        if str(cat).strip() in ('促销装', '非卖品'):
            return '超销-促销装'
        return '未分类'

    # ---- 5) write ----
    q_f = ws.cell(row=2, column=17).value
    r_f = ws.cell(row=2, column=18).value
    GRAY_FILL = PatternFill(patternType='solid', fgColor=Color(rgb='FFCCCCCC'))

    src_rows = []
    for rr in range(2, ws_src.max_row + 1):
        src_rows.append([ws_src.cell(row=rr, column=c).value for c in range(1, 16)])
    print('源数据行数:', len(src_rows))

    for i, s in enumerate(src_rows):
        r = i + 2
        for c in range(1, ws.max_column + 1):
            copy_style(ws.cell(row=2, column=c), ws.cell(row=r, column=c))

        rdc = s[1]; mat = s[2]; cat = s[5]; abc = s[6]; cdc = s[14]
        rdc_stock = s[11]; rdc_transit = s[12]; backlog = s[13]
        reason_txt = reason(rdc, mat, cat, abc, cdc, rdc_stock, rdc_transit, backlog)

        j_val = s[9]
        if j_val is None or (isinstance(j_val, str) and j_val.strip() == ''):
            if reason_txt == '淘汰产品':
                j_val = '淘汰产品'
            elif reason_txt == '总仓缺货':
                j_val = '总仓到货后补货'
            else:
                nd = next_replen(rdc)
                if nd is not None:
                    j_val = f'{nd.month}-{nd.day}补货'

        # 变动5：在途数量 < 缺货数量，且本身有在途量、且原因非淘汰/总仓缺货
        # → 在“补货到货时间”(J) 末尾追加 “，剩余缺口预计M-D补货”
        #   日期与字段空白时一致：next_replen(rdc)（严格晚于报告日的下一个补货日）
        transit_qty = to_num_rule(s[12])   # RDC在途库存(列M/13)
        shortage_qty = to_num_rule(s[8])   # 缺货数量(列I/9)
        if (transit_qty > 0 and transit_qty < shortage_qty
                and reason_txt not in ('淘汰产品', '总仓缺货')):
            nd = next_replen(rdc)
            if nd is not None:
                suffix = f'，剩余缺口预计{nd.month}-{nd.day}补货'
                base = j_val if isinstance(j_val, str) and j_val.strip() != '' else ''
                j_val = (base + suffix) if base else suffix.lstrip('，')

        vals = {
            1: REPORT_DATE, 2: rdc, 3: s[2], 4: s[3], 5: s[4], 6: s[5],
            7: s[6], 8: s[7], 9: to_num(s[8]), 10: j_val, 12: reason_txt,
            13: to_num(s[11]), 14: to_num(s[12]), 15: to_num(s[13]), 16: to_num(s[14]),
        }
        for col, v in vals.items():
            ws.cell(row=r, column=col).value = v

        ws.cell(row=r, column=11).value = ka_map.get(norm_code(mat))
        if q_f:
            ws.cell(row=r, column=17).value = q_f.replace('C2', f'C{r}')
        if r_f:
            ws.cell(row=r, column=18).value = r_f.replace('C2', f'C{r}')

    # ---- 6) 淘汰产品整行灰色（其余保留模板原底色） ----
    for r in range(2, 2 + len(src_rows)):
        if ws.cell(row=r, column=12).value == '淘汰产品':
            for c in range(1, ws.max_column + 1):
                ws.cell(row=r, column=c).fill = copy(GRAY_FILL)

    for r in range(2, 2 + len(src_rows)):
        ws.cell(row=r, column=1).number_format = 'yyyy/m/d'
    ws.column_dimensions['A'].width = 12
    for col in ['B', 'C', 'I', 'L', 'M', 'N', 'O', 'P']:
        if (ws.column_dimensions[col].width or 0) < 8:
            ws.column_dimensions[col].width = 8

    if ws.max_row > 1 + len(src_rows):
        ws.delete_rows(2 + len(src_rows) + 1, ws.max_row - (1 + len(src_rows)))

    # ---- 7) 保存：本地临时→去Zone标记→复制到目标→删临时 ----
    tmp = os.path.join(os.path.expanduser('~'), 'Desktop',
                       f'_stockout_tmp_{REPORT_DATE.strftime("%Y%m%d")}.xlsx').replace('\\', '/')
    wb_tpl.save(tmp)
    ads = tmp + ':Zone.Identifier'
    if os.path.exists(ads):
        try:
            os.remove(ads)
        except Exception:
            pass
    shutil.copy(tmp, OUT)
    try:
        os.remove(tmp)
    except Exception:
        pass
    print('已生成:', OUT)

    # ---- 8) verify ----
    wb_v = openpyxl.load_workbook(OUT, data_only=False)
    wsv = wb_v['缺货报告']
    lcnt = Counter(); kcnt = 0; gray = 0
    for r in range(2, wsv.max_row + 1):
        lv = wsv.cell(row=r, column=12).value
        if lv:
            lcnt[str(lv)] += 1
        if wsv.cell(row=r, column=11).value not in (None, ''):
            kcnt += 1
        if wsv.cell(row=r, column=1).fill.fill_type == 'solid':
            gray += 1
    print('缺货原因分布:', dict(lcnt))
    print(f'K(CDC到货)有值={kcnt}, 灰色行={gray} (淘汰产品应={lcnt.get("淘汰产品", 0)})')


if __name__ == '__main__':
    main()
